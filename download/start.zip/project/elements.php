<!DOCTYPE html>
<html lang="uk">
<head>
  <?php include 'inc/_top.php';?>
  <title>Yoki | Elements</title>
</head>
<body>

  <!-- LOADER -->
  <div class="loader"></div>

  <div id="content-block">

    <!-- HEADER -->
    <header class="user">
      <?php include 'inc/_header.php';?>
    </header>
    <div class="header-margin"></div>

    <main class="main">
      
      <!-- h1 h2 h3 h4 h5 h6 -->
      <!-- <div class="section">
        <div class="spacer-sm"></div>
        <div class="container">
          <div class="row">
            <div class="col-12">
              <h1 class="h1 title text-upper text-line-2">Популярні страви</h1>
              <h2 class="h2 title text-upper text-line-2">Популярні страви</h2>
              <h3 class="h3 title text-upper text-line-2">Популярні страви</h3>
              <h4 class="h4 title text-upper text-line-2">Популярні страви</h4>
              <h5 class="h5 title text-upper text-line-2">Популярні страви</h5>
              <h6 class="h6 title text-upper text-line-2">Популярні страви</h6>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- UL -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="text">
                <ul>
                  <li>Антитіла IgG до аскарид (Ascaris lumbricoides)</li>
                  <li>Антитіла Ig G до токсокар (Toxocara canis)</li>
                  <li>Антитіла IgM, IgA, IgG до лямблій (Giardia Lamblia intestinalis)</li>
                  <li>Антитіла IgG до опісторхів (Opisthorchis felineus)</li>
                  <li>Антитіла IgA, IgG до ехінококу (Echinococcus granulosus)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- OL -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="text">
                <ol>
                  <li>Антитіла IgG до аскарид (Ascaris lumbricoides)</li>
                  <li>Антитіла Ig G до токсокар (Toxocara canis)</li>
                  <li>Антитіла IgM, IgA, IgG до лямблій (Giardia Lamblia intestinalis)</li>
                  <li>Антитіла IgG до опісторхів (Opisthorchis felineus)</li>
                  <li>Антитіла IgA, IgG до ехінококу (Echinococcus granulosus)</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- TEXT -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-xl-6 col-lg-8 col-md-10">
              <div class="h2 title title-margin-20">Ресторан Yoki став ще ближчим для кожного</div>
              <div class="text">
                <p>Посеред хаосу та шаленого ритму міста, в самісінькому його центрі , на кожного самурая та близьку йому людину чекає неповторна азійська пригода.</p>
                <p>Авторські коктейлі, азійська кухня, ексклюзивні вечірки і шалена атмосфера не лишає байдужим нікого. Чекаємо, аби ловити «Дзен» разом!</p>
              </div>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- BLOCKQUOTE -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-xl-10 col-12">
              <blockquote>75% діагностичної інформації лікар отримує з результатів лабораторних досліджень. Точний результат аналізів дозволяє лікареві правильно встановити діагноз пацієнту та призначити ефективне лікування</blockquote>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- PAGINATION -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-xl-8 col-lg-10 col-12">
              <div class="custom-pagination">
                <ul>
                  <li class="arrow left disabled">
                    <a href="#">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19 12H5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 19L5 12L12 5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </a>
                  </li>
                  <li class="active"><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#">4</a></li>
                  <li class="dott">...</li>
                  <li><a href="#">13</a></li>
                  <li class="arrow right">
                    <a href="#">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 5L19 12L12 19" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- LINKS & BTNS -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-xl-6 col-lg-8 col-md-10 col-12">
              <div class="btn">
                <a href="#" class="btn"><span>детальніше</span></a>
              </div>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- FORM -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-xl-6 col-lt-8 col-lg-10 col-12">
              <form>
                <div class="form-block">
                  <input class="input" type="text" name="name" placeholder="*Ваше ім’я" required>
                  <input class="input" type="text" name="lastname" placeholder="*Ваше прізвище" required>
                </div>
                <input class="input inputmask" type="text" name="phone" data-inputmask="'mask': '+38 (999) 999 99 99'" data-inputmask-placeholder="x" placeholder="*Ваш номер телефону" required>
                <textarea class="input" placeholder="Коментар"></textarea>
                <div class="form-bottom">
                  <button type="submit" class="btn"><span>ЗАРЕЄСТРУВАТИСЬ</span></button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->

      <!-- POPUPS -->
      <!-- <div class="section">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="btn-block">
                <a href="#" class="btn white open-popup" data-rel="location"><span>Location Popup</span></a>
              </div>
            </div>
          </div>
        </div>
        <div class="spacer-sm"></div>
      </div> -->
      
    </main>

    <!-- FOOTER -->
    <footer>
      <?php include 'inc/_footer.php';?>
    </footer>

    <!-- POPUP -->
    <div class="popup-wrapper" id="popups">
    </div>

  </div>

  <!-- JS -->
  <script defer src="js/inputmask.js"></script>

  <?php include 'inc/_bottom.php';?>

</body>
</html>