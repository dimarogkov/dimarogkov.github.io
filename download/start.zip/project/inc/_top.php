<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="format-detection" content="telephone=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<meta name='robots' content='noindex,nofollow'>
<link rel="shortcut icon" href="img/favicon.ico">
<!-- CSS -->
<link href="css/bootstrap-grid.min.css" rel="stylesheet" type="text/css" />
<link href="css/font.css" rel="stylesheet" type="text/css">
<link href="css/main.css" rel="stylesheet" type="text/css">
<!-- on php delete this css for desktop and add for mobile -->
<link href="css/main_mobile.css" rel="stylesheet" type="text/css">