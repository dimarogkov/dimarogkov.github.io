<!-- CSS -->
<link href="css/bootstrap.bottom.css" rel="stylesheet" type="text/css">

<link href="css/style.css" rel="stylesheet" type="text/css">
<!-- on php delete this css for desktop and add for mobile -->
<link href="css/style_mobile.css" rel="stylesheet" type="text/css">

<!-- JS -->
<script src="js/jquery-3.5.1.min.js"></script>

<!-- on php delete this js for mobile -->
<script defer src="js/SmoothScroll.js"></script>

<script defer src="js/custom-lazy.js"></script>
<script defer src="js/global.js"></script>
