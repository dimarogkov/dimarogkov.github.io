// =============================
// JS
// =============================
// 1) LAYER-CLOSE
// 2) SITE READY
// 3) SCROLL
// 4) INVALID INPUT
// 5) POPUP
// 6) AJAX POPUP
// 7) SWIPER
// 8) HEADER
// 9) INPUTMASK
// 10) MORE TEXT
// 11) RELLAX
// 12) SUMOSELECT
// =============================

var _functions = {}, winWidth;

jQuery(function($) {

  "use strict";
        
  /* function on page ready */
  var isTouchScreen = navigator.userAgent.match(/Android/i) ||navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i);
  if (isTouchScreen) $('html').addClass('touch-screen');
  var winScr, winHeight,
      is_Mac = navigator.platform.toUpperCase().indexOf('MAC') >= 0,
      is_IE = /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /MSIE 10/i.test(navigator.userAgent) || /Edge\/\d+/.test(navigator.userAgent),
      is_Chrome = navigator.userAgent.indexOf('Chrome') >= 0 && navigator.userAgent.indexOf('Edge') < 0;

  /* check browser */
  winWidth = $(window).width();
  winHeight = $(window).height();

  if(is_Mac){$('html').addClass('mac');}
  if(is_IE){$('html').addClass('ie');}
  if(is_Chrome){$('html').addClass('chrome');}

  /* function on page scroll */
  $(window).scroll(function(){
    _functions.scrollCall();
  });


  // =============================
  // LAYER-CLOSE
  // =============================
  $(document).on('click', '.layer-close', function (e) {
    e.preventDefault();
    $(this).removeClass('active');
  });


  // =============================
  // SITE READY
  // =============================
  setTimeout(function() {
    $('.loader').addClass('hide');
    $('.loader').on('transitionend webkitTransitionEnd oTransitionEnd', function() {
      $(this).remove();
    });
  },700);
  setTimeout(function() {
    $('body').addClass('site-ready');
  }, 700);


  // =============================
  // SCROLL
  // =============================
  var prev_scroll = 0;

  _functions.scrollCall = function() {
    winScr = $(window).scrollTop();
    if (winScr > 10) {
      $('header').addClass('scrolled');
    } else {
      $('header').removeClass('scrolled');
    }
  }
  _functions.scrollCall();

  //anchor scroll
  $(function () {
    $('a[href*="#"]:not([href="#"])').click(function () {
      if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
        if (target.length) {
          $('html, body').animate({
            scrollTop: target.offset().top - 162
          }, 888);
          $('html').removeClass('overflow-hidden');
          $('header').removeClass('active-layer-close');
          return false;
        }
      }
    });
  });


  // =============================
  // INVALID INPUT
  // =============================
  $(document).on('blur', '.input[required]', function(){
    if($(this).val().trim()){
      $(this).removeClass('invalid');
    } else {
      $(this).addClass('invalid');
    }
  });

  
  // =============================
  // POPUP
  // =============================
  var popupTop = 0;
  function removeScroll() {
      popupTop = $(window).scrollTop();
      $('body').addClass('lock');
  }
  function addScroll(){
    $('body').removeClass('lock');
  }
  _functions.openPopup = function(popup){
    $('.popup-content').removeClass('active');
    $(popup + ', .popup-wrapper').addClass('active');
    removeScroll();
  };
  _functions.closePopup = function(){
    $('.popup-wrapper, .popup-content').removeClass('active');
    addScroll();
  };
  _functions.textPopup = function(title, description){
    $('#text-popup .text-popup-title').html(title);
    $('#text-popup .text-popup-description').html(description);
    _functions.openPopup('#text-popup');
  };
  $(document).on('click', '.open-popup', function(e){
    e.preventDefault();
    _functions.openPopup('.popup-content[data-rel="' + $(this).data('rel') +'"]');
  });
  $(document).on('click', '.popup-wrapper .btn-close, .popup-wrapper .layer-close, .popup-wrapper .close-popup, .popup-align .popup-btn-close', function(e){
    e.preventDefault();
    _functions.closePopup();
  });
  $(document).keyup(function(e){
    if (e.keyCode === 27 ){
      _functions.closePopup();
    }
  });


  // =============================
  // AJAX POPUP
  // =============================
  function loadPopup() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200){
        document.getElementById("popups").innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", "inc/_popup.php", true);
    xhttp.send();
  }
  $('.open-popup').click(function(){
    loadPopup();
    $('.popup-wrapper').addClass('active');
    let dataRel = $(this).attr('data-rel');

    setTimeout( function(){
      if ($('.SelectBox').length) {
        $('.SelectBox').each(function () {
            $(this).SumoSelect({
                floatWidth: 0,
                nativeOnDevice: []
            });
        });
      }
    }, 100);

    setTimeout( function(){
      $(".inputmask").inputmask({
          showMaskOnHover: false
      });
    }, 1000);

    setTimeout( function(){
      $('.popup-wrapper .popup-content').each(function () {
        const thisPopup = $(this).attr('data-rel')
        if (dataRel === thisPopup){
          $(this).addClass('active')
        } else {
          $(this).removeClass('active')
        }
      });
    },100);
  });


  // =============================
  // SWIPER
  // =============================
  _functions.getSwOptions = function(swiper){
    var options = swiper.data('options'),
        initialSlideNum = swiper.data('initial-slide');
        options = (!options || typeof options !=='object') ? {} : options;
        var $p = swiper.closest('.swiper-entry'),
            slidesLength = swiper.find('>.swiper-wrapper>.swiper-slide').length;
    if(!options.pagination) options.pagination = {
      el: $p.find('.swiper-pagination')[0],
      clickable: true
    };
    if(!options.navigation) options.navigation = {
      nextEl: $p.find('.swiper-button-next')[0],
      prevEl: $p.find('.swiper-button-prev')[0]
    };
    if (initialSlideNum) options.initialSlide = initialSlideNum;
    options.preloadImages = false;
    options.lazy = {loadPrevNext: true};
    options.observer = true;
    options.observeParents = true;
    options.watchOverflow = true;
    if(!options.speed) options.speed = 500;
    options.roundLengths = false;
    options.centerInsufficientSlides = true;
    if(!options.centerInsufficientSlides) options.centerInsufficientSlides = false;
    if(slidesLength <= 1){
      options.loop = false;
    }
    if(winWidth < 992) options.direction = "horizontal";
    return options;
  };

  _functions.initSwiper = function(el){
    var swiper = new Swiper(el[0], _functions.getSwOptions(el));
  };

  $('.swiper-entry .swiper-container').each(function(){
    _functions.initSwiper($(this));
  });


  // =============================
  // HEADER
  // =============================
  $('.list').on('mousemove', function() {
    $(this).addClass('active');
  });
  $('.list').on('mouseleave', function() {
    $(this).removeClass('active');
  });

  if (winWidth < 1200) {
    $(document).on('click', '.header-left-menu ul li div', function() {
      $(this).toggleClass('active');
      $(this).parent().find('ul').slideToggle();
    });
  }
  if (winWidth > 1200) {
    let widthLeft = +$('.header-bottom-left').width(),
        widthRight = +$('.header-basket').width(),

        PaddingLeft = $('.header-basket').css('padding-left'),
        PaddingRight = $('.header-basket').css('padding-right'),
        PaddingLeftNum = parseInt(PaddingLeft.match(/\d+/)),
        PaddingRightNum = parseInt(PaddingRight.match(/\d+/)),

        padding = PaddingLeftNum + PaddingRightNum,
        width;

        widthRight = widthRight + padding;
        width = widthLeft + widthRight;
        
    $('.header-menu').css({
      "width": "calc(100% - "+ width +"px)",
      "margin": "0 "+ widthRight +"px 0 "+ widthLeft +"px"
    });
  }
  $(document).on('click', '.header-burger', function(e) {
    e.preventDefault();
    $(this).toggleClass('active');
    $('body').toggleClass('lock');
    $('header').toggleClass('active-layer-close');
    $('.header-left-menu').toggleClass('active');
  });
  $(document).on('click', '.layer-close', function() {
    $('.header-burger').removeClass('active');
    $('body').removeClass('lock');
    $('header').removeClass('active-layer-close');
    $('.header-left-menu').removeClass('active');
  });


  // =============================
  // INPUTMASK
  // =============================
  $(document).on('blur', '.input[required]', function(){
    if($(this).val().trim()){
      $(this).removeClass('invalid');
    } else {
      $(this).addClass('invalid');
    }
  });
  if ($(".inputmask").length) {
    $(".inputmask").inputmask({
      showMaskOnHover: false
    });
  };


  // =============================
  // MORE TEXT
  // =============================
  $(document).on('click', '.read-more', function () {
    $(this).closest('.feedback-slide').toggleClass('hide-more');
    $(this).closest('.feedback-slide').find('.more-text').slideToggle(300);
  });


  // =============================
  // RELLAX
  // =============================
  if(!is_IE && $('.rellax').length && winWidth > 1199 && $('body').hasClass('site-ready')){
    let rellax = new Rellax('.rellax');
  }


  // =============================
  // SUMOSELECT
  // =============================
  if ($('.SelectBox').length) {
    $('.SelectBox').each(function () {
        $(this).SumoSelect({
          floatWidth: 0,
          nativeOnDevice: []
        });
    });
  }


});