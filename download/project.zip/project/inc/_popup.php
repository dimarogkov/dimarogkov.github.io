<div class="bg-layer"></div>

<!-- location -->
<div class="popup-content" data-rel="location">
  <div class="layer-close"></div>
  <div class="popup-container location-popup">
    <div class="popup-align">
      <div class="popup-cont">
        <div class="h3 title text-line-2">Виберіть місто</div>
        <div class="text text-line-2">Оберіть будь ласка місто доставки суші</div>
      </div>
      <a href="#" class="btn-close"></a>
    </div>
  </div>
</div>